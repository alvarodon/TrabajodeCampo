package Principal;

import Gestor.Gestor;
import Vista.JFrame_Inicio;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author treme
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JFrame_Inicio inicio=new JFrame_Inicio();
        inicio.setVisible(true);
        
    }
    
}
